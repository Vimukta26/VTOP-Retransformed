please install pip install customtkinter

login to online PowerBI(using college email Id) and request access from the administrator 